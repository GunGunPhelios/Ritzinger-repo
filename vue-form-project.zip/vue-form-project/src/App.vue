<template>
  <div id="app">
    <ValidationForm />
  </div>
</template>

<script>
import ValidationForm from './components/ValidationForm.vue'

export default {
  components: {
    ValidationForm
  }
}
</script>