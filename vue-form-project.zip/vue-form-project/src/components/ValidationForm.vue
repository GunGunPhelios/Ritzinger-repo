<template>
<form @submit.prevent="submitForm">
  <div>
    <label for="name">Név:</label>
    <input id="name" v-model="form.name" required />
  </div>
  <div>
    <label for="email">Email:</label>
    <input id="email" v-model="form.email" required />
    <span v-if="emailError" style="color:red">{{ emailError }}</span>
  </div>
  <div>
    <label for="phone">Telefonszám:</label>
    <input id="phone" v-model="form.phone" required />
    <span v-if="phoneError" style="color:red">{{ phoneError }}</span>
  </div>
  <button type="submit">Küldés</button>
  <div v-if="submitted">
    <h3>Beküldött adatok</h3>
    <p>Név: {{ form.name }}</p>
    <p>Email: {{ form.email }}</p>
    <p>Telefonszám: {{ form.phone }}</p>
  </div>
</form>
</template>

<script>
export default {
  data() {
    return {
      form: {
        name: '',
        email: '',
        phone: ''
      },
      emailError: '',
      phoneError: '',
      submitted: false
    };
  },
  methods: {
    validateEmail(email) {
      const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return re.test(email);
    },
    validatePhone(phone) {
      const re = /^\+?\d{7,15}$/;
      return re.test(phone);
    },
    submitForm() {
      this.emailError = '';
      this.phoneError = '';
      let valid = true;
      if (!this.validateEmail(this.form.email)) {
        this.emailError = 'Érvénytelen email cím';
        valid = false;
      }
      if (!this.validatePhone(this.form.phone)) {
        this.phoneError = 'Érvénytelen telefonszám';
        valid = false;
      }
      if(valid) {
        this.submitted = true;
      }
    }
  }
};
</script>