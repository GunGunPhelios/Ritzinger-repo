import { createApp } from 'vue'
import App from './App.vue'
// Import the Vue Router instance
import router from './router'

// Create the app and mount it to the #app element
createApp(App)
  .use(router) // tell Vue to use the router
  .mount('#app')