<script setup>
import { ref } from 'vue'

// define the props accepted by this component
defineProps({
  msg: String
})

const count = ref(0)
</script>

<template>
  <div class="my-4 p-4 border rounded shadow bg-white">
    <h2 class="text-xl font-semibold mb-2">{{ msg }}</h2>
    <div class="card mb-2">
      <button
        type="button"
        class="px-4 py-2 bg-blue-500 text-white rounded"
        @click="count++"
      >
        count is {{ count }}
      </button>
      <p class="mt-2 text-gray-600">
        Szerkeszd a
        <code>components/HelloWorld.vue</code>
        fájlt a forró frissítés teszteléséhez.
      </p>
    </div>
    <p class="text-gray-600">
      Nézd meg a
      <a
        href="https://vuejs.org/guide/quick-start.html#local"
        target="_blank"
        class="text-blue-600 underline"
        >create-vue</a
      >
      útmutatót a hivatalos Vue + Vite starterhez.
    </p>
    <p class="text-gray-600">
      Tudj meg többet az IDE támogatásról a
      <a
        href="https://vuejs.org/guide/scaling-up/tooling.html#ide-support"
        target="_blank"
        class="text-blue-600 underline"
        >Vue dokumentáció Scaling up útmutatójában</a
      >.
    </p>
    <p class="read-the-docs text-gray-500 mt-2">
      Kattints a Vite és Vue logókra, hogy többet tudj meg.
    </p>
  </div>
</template>

<style scoped>
.read-the-docs {
  color: #888;
}
</style>