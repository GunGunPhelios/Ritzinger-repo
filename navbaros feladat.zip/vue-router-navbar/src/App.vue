<template>
  <div id="app" class="min-h-screen bg-gray-100">
    <!-- Navigation bar -->
    <Navbar />
    <!-- Router view renders the matched component for the current route -->
    <router-view />
  </div>
</template>

<script>
import Navbar from './components/Navbar.vue'

export default {
  name: 'App',
  components: {
    Navbar
  }
}
</script>