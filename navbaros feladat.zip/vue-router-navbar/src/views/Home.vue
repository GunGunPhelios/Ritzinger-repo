<template>
  <div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">Kezdőlap</h1>
    <p class="mb-4">Ez az alkalmazás kezdőoldala.</p>
    <!-- Include the HelloWorld component to demonstrate dynamic Vue components -->
    <HelloWorld msg="Üdv a Vue Router alkalmazásban!" />
  </div>
</template>

<script>
import HelloWorld from '../components/HelloWorld.vue'

export default {
  name: 'Home',
  components: {
    HelloWorld
  }
}
</script>