import { createRouter, createWebHistory } from 'vue-router'
import Home from '../views/Home.vue'
import Books from '../views/Books.vue'
import Contact from '../views/Contact.vue'

// Define application routes. Each route maps a URL path to a component.
const routes = [
  { path: '/', name: 'Home', component: Home },
  { path: '/books', name: 'Books', component: Books },
  { path: '/contact', name: 'Contact', component: Contact }
]

// Create a router instance. We use HTML5 history mode so the URL looks clean.
const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router