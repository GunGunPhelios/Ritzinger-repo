# Projektmunka II – Navigációs alkalmazás kiegészítése

Ez az alkalmazás egy egyszerű Vue 3 projekt, amely három statikus oldal között enged navigálni a Vue Router segítségével. A feladat szerint kiegészítettem a projektet két hiányzó funkcióval:

1. **HelloWorld** komponens integrálása az alkalmazásba
2. **CSS könyvtár** (Tailwind CSS) beépítése és osztályok alkalmazása az oldalak formázásához

Az alábbiakban részletezem a lépéseket, amelyeket a hiányzó funkciók megvalósításához végrehajtottam.

## 1. A projekt létrehozása Vite‑tel és a Vue Router telepítése

1. **Új projekt létrehozása** (ha van internetkapcsolat):

   ```bash
   npm create vite@latest vue-router-navbar -- --template vue
   cd vue-router-navbar
   npm install
   npm install vue-router@4
   ```

   Ha a Vite sablon nem telepíthető (pl. internetkorlátozás miatt), manuálisan is létrehozható a mappa és a szükséges fájlok. A `package.json`‑ban felvettem a `vue` és `vue-router` függőségeket, valamint a Vite és a Vue plugint a fejlesztési függőségekhez. A `vite.config.js` fájlban engedélyeztem a Vue plugint.

2. **Vite konfiguráció** (`vite.config.js`):

   ```js
   import { defineConfig } from 'vite'
   import vue from '@vitejs/plugin-vue'

   export default defineConfig({
     plugins: [vue()]
   })
   ```

3. **index.html** létrehozása**:** a gyökér elem (`<div id="app"></div>`) és a Tailwind CSS CDN linkje. A Tailwindet CDN-en keresztül integráltam, így nem szükséges telepíteni.

4. **src/main.js**: itt hoztam létre az alkalmazást és regisztráltam a routert.

   ```js
   import { createApp } from 'vue'
   import App from './App.vue'
   import router from './router'

   createApp(App).use(router).mount('#app')
   ```

5. **src/router/index.js**: definiáltam a három útvonalat (Home, Books, Contact) és létrehoztam a routert HTML5 history móddal.

   ```js
   import { createRouter, createWebHistory } from 'vue-router'
   import Home from '../views/Home.vue'
   import Books from '../views/Books.vue'
   import Contact from '../views/Contact.vue'

   const routes = [
     { path: '/', name: 'Home', component: Home },
     { path: '/books', name: 'Books', component: Books },
     { path: '/contact', name: 'Contact', component: Contact }
   ]

   const router = createRouter({
     history: createWebHistory(),
     routes
   })

   export default router
   ```

## 2. HelloWorld komponens integrálása

1. A megadott `HelloWorld.vue` komponens **elhelyezése** a `src/components` mappában. A komponens a Vue Composition API-t használja, egy `count` változóval és egy `msg` propsszal.

2. **Tailwind osztályok hozzáadása** a komponenshez: a sablon elemeit Tailwind osztályokkal bővítettem (`p-4`, `border`, `rounded`, stb.), így az oldal stílusához illeszkedik.

3. **Home.vue frissítése**: importáltam a HelloWorld komponenst és elhelyeztem a kezdőlapon. A `msg` propsszal köszöntő üzenetet adtam át.

   ```vue
   <template>
     <div class="p-6">
       <h1 class="text-2xl font-semibold mb-4">Kezdőlap</h1>
       <p class="mb-4">Ez az alkalmazás kezdőoldala.</p>
       <HelloWorld msg="Üdv a Vue Router alkalmazásban!" />
     </div>
   </template>

   <script>
   import HelloWorld from '../components/HelloWorld.vue'
   export default {
     name: 'Home',
     components: { HelloWorld }
   }
   </script>
   ```

## 3. Tailwind CSS integrálása és alkalmazása

1. **Tailwind CDN**: Az `index.html` fájl `<head>` részébe beillesztettem a `https://cdn.tailwindcss.com` szkriptet. Ez lehetővé teszi a Tailwind osztályok azonnali használatát telepítés nélkül.

2. **Navbar stilizálása** (`src/components/Navbar.vue`): a navigációs sávot Tailwind osztályokkal formáztam (`bg-blue-600`, `text-white`, `p-4`, `flex`, `gap-4`). A router linkekhez `hover:underline` és `exact-active-class="underline"` került.

3. **Oldalak formázása**: A Home, Books és Contact nézeteknél Tailwind osztályokat használtam a margók, betűméretek és színek beállítására (`p-6`, `text-2xl`, `font-semibold`, `mb-4`).

4. **HelloWorld komponens**: a gomb Tailwind gombstílust kapott (`px-4`, `py-2`, `bg-blue-500`, `text-white`, `rounded`), továbbá a konténer árnyékot és lekerekített széleket.

## 4. Git verziókezelés és feltöltés

1. **Git inicializálás**:
   ```bash
   git init
   git add .
   git commit -m "Initial commit – navigáció, HelloWorld integráció és Tailwind"
   ```

2. **Távoli tároló beállítása**:
   ```bash
   git remote add origin <saját‑repo‑URL>
   git branch -M main
   git push -u origin main
   ```

Az elkészült projektet a tanár által megadott GitHub repóba kell feltölteni. A `README.md` fájl ennek a projektnek a részeként került mentésre.

## 5. Futatás

Indítsd a fejlesztői szervert a projekt gyökerében:

```bash
npm install
npm run dev
```

A böngésző megnyitása után (általában http://localhost:5173/) látható a navigációs sáv, a három oldal, a HelloWorld komponens a kezdőlapon és a Tailwind CSS stílusai.

---

Ez a dokumentáció leírja a projekt bővítéséhez szükséges lépéseket. A hiányzó funkciók (HelloWorld integráció és CSS könyvtár használata) ezzel maradéktalanul megvalósultak.