<template>
  <nav class="bg-blue-600 text-white p-4 flex gap-4">
    <!-- Vue Router links for navigation -->
    <router-link to="/" class="font-bold hover:underline" exact-active-class="underline">
      Kezdőlap
    </router-link>
    <router-link to="/books" class="font-bold hover:underline" exact-active-class="underline">
      Könyvek
    </router-link>
    <router-link to="/contact" class="font-bold hover:underline" exact-active-class="underline">
      Kapcsolat
    </router-link>
  </nav>
</template>

<script>
export default {
  name: 'Navbar'
}
</script>