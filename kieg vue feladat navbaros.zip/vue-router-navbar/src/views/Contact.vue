<template>
  <div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">Kapcsolat</h1>
    <p>Itt találod a kapcsolatfelvételi információkat.</p>
  </div>
</template>

<script>
export default {
  name: 'Contact'
}
</script>