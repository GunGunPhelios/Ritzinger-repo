<template>
  <div class="p-6">
    <h1 class="text-2xl font-semibold mb-4">Könyvek oldal</h1>
    <p>Itt vannak a könyvek adatai.</p>
  </div>
</template>

<script>
export default {
  name: 'Books'
}
</script>